package com.example.flowerapp

class Model {

    val listOfFlowerObjects: MutableList<Flower> = mutableListOf(

        Flower("Flower1", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower2", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower3", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower4", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower5", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower6", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower7", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower8", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower9", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower10", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower11", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower12", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower13", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower14", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower15", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower16", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower17", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower18", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower19", R.drawable.ic_baseline_local_florist_24),
        Flower("Flower20", R.drawable.ic_baseline_local_florist_24)
    )
}