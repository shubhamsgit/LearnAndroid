package com.example.flowerapp

data class Flower(val name: String, val img: Int)